const backBtn = document.getElementById("close-btn");

backBtn.addEventListener("click", () => {
    // Go back to the previous page
    window.history.back();
});